var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(
        policy =>
        {
            policy.SetIsOriginAllowed(origin => new Uri(origin).Host == "localhost");
        });
});

var app = builder.Build();

app.MapGet("/", () => $"Hello World! {Guid.NewGuid()}");

app.UseCors();

app.Run();
